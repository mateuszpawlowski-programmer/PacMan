/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pacman;

import java.util.Random;

/**
 *
 * @author M
 */
public class Ghost {

public int pos_x,pos_y;
public int last_pos_x,last_pos_y;

public boolean blocked=false;

public int x,y;

public int move_dir;

public String ghost_type;

public boolean scary_state=false;
public boolean alive=true;

public int current_frame=0;

public boolean ghost_moving_left = false;
public boolean ghost_moving_right = false;
public boolean ghost_moving_up = false;
public boolean ghost_moving_down = false;
        
public int[][] collision_map=new int[31][28];

public static Random mov=new Random();
        
Ghost(String type,int px,int py)
{

    ghost_type=type;
    x=px;
    y=py;
    
    pos_x=x*15;
    pos_y=y*16;
    
    
    collision_map =new int[][]                                  {{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
								,{1,0,0,0,0,0,4,0,0,0,0,0,0,1,1,0,0,0,0,0,0,4,0,0,0,0,0,1}
								,{1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1}
								,{1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1}
								,{1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1}
								,{1,0,0,0,0,0,10,0,0,4,0,0,9,0,0,9,0,0,4,0,0,10,0,0,0,0,0,1}
								,{1,0,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,0,1}
								,{1,0,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,0,1}
								,{1,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,1}
								,{1,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1}
								,{1,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0}
								,{1,1,1,1,1,1,0,1,1,0,0,0,9,0,0,9,0,0,0,1,1,0,1,1,1,1,1,0}
								,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0}
								,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1}
								,{0,0,0,0,0,0,6,0,0,0,1,1,1,1,1,1,1,1,0,0,0,7,0,0,0,0,0,0}
								,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1}
								,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0}
								,{1,1,1,1,1,1,0,1,1,6,0,0,0,0,0,0,0,0,9,1,1,0,1,1,1,1,1,0}
								,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0}
								,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1}
								,{1,0,0,0,0,0,10,0,0,9,0,0,0,1,1,0,0,0,9,0,0,10,0,0,0,0,0,1}
								,{1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1}
								,{1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1}
								,{1,0,0,0,1,1,0,0,0,4,0,0,9,0,0,9,0,0,4,0,0,0,1,1,0,0,0,1}
								,{1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1}
								,{1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1}
								,{1,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,1}
								,{1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1}
								,{1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1}
								,{1,0,0,0,0,0,0,0,0,0,0,0,9,0,0,9,0,0,0,0,0,0,0,0,0,0,0,1}
								,{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
	};
        
        
        
        int rmov=mov.nextInt(2);
        if(rmov==0) move_dir=4;
        if(rmov==1) move_dir=6;
}

public void animate()
{
this.current_frame++;
if(this.current_frame==2) this.current_frame=0;
}

public void move()
{
    if(pos_x%16==0) x=(int)(pos_x/16);
    if(pos_y%16==0) y=(int)(pos_y/16);
    
    
    
    
    if(pos_x%16==0&&pos_y%16==0)
    {
        if(blocked==true){
        
        if(collision_map[y][x]==0)
        {
            blocked=false;
            int rmov=mov.nextInt(4);
            if(rmov==0) move_dir=8;
            if(rmov==1) move_dir=2;
            if(rmov==2) move_dir=6;
            if(rmov==3) move_dir=4;
        }
        }
        
        if(collision_map[y][x]==9)
        {
            int rmov=mov.nextInt(3);
            if(rmov==0) move_dir=8;
            if(rmov==1) move_dir=4;
            if(rmov==2) move_dir=6;
        }
        
        if(collision_map[y][x]==4)
        {
            int rmov=mov.nextInt(3);
            if(rmov==0) move_dir=2;
            if(rmov==1) move_dir=4;
            if(rmov==2) move_dir=6;
        }
        
        if(collision_map[y][x]==10)
        {
            int rmov=mov.nextInt(4);
            if(rmov==0) move_dir=8;
            if(rmov==1) move_dir=4;
            if(rmov==2) move_dir=6;
            if(rmov==3) move_dir=2;
        }
        
        if(collision_map[y][x]==6)
        {
            int rmov=mov.nextInt(4);
            if(rmov==0) move_dir=8;
            if(rmov==1) move_dir=4;
            if(rmov==2) move_dir=6;
            if(rmov==3) move_dir=2;
        }
        
        if(collision_map[y][x]==7)
        {
            int rmov=mov.nextInt(4);
            if(rmov==0) move_dir=8;
            if(rmov==1) move_dir=4;
            if(rmov==2) move_dir=6;
            if(rmov==3) move_dir=2;
        }
        
    }
    
    
    
    
    
    blocked=true;
    if(move_dir==4)
    {
        if(collision_map[y][x-1]!=1) {blocked=false;pos_x=pos_x-1;}
    };
    
    if(move_dir==6)
    {
        if(collision_map[y][x+1]!=1) {blocked=false;pos_x=pos_x+1;}
    };
    
    if(move_dir==8)
    {
        if(collision_map[y-1][x]!=1) {blocked=false;pos_y=pos_y-1;}
    };
    
    if(move_dir==2)
    {
        if(collision_map[y+1][x]!=1) {blocked=false;pos_y=pos_y+1;}
    };
}

    

}

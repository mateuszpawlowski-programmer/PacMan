/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pacman;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class PacMan extends JPanel implements Runnable,KeyListener{

    public JPanel panel=new JPanel();
    public JFrame frame=new JFrame("Pac Man");
    public Thread thread;
    
    BufferedImage  corner_1;
    BufferedImage  corner_2;
    BufferedImage  corner_3;
    BufferedImage  corner_4;
    BufferedImage  horizontal;
    BufferedImage  vertical;
    BufferedImage  big_dot;
    BufferedImage  dot;
    
    BufferedImage pacman_0f;
    BufferedImage pacman_down_1f;
    BufferedImage pacman_down_2f;
    BufferedImage pacman_up_1f;
    BufferedImage pacman_up_2f;
    BufferedImage pacman_left_1f;
    BufferedImage pacman_left_2f;
    BufferedImage pacman_right_1f;
    BufferedImage pacman_right_2f;
    
    
    BufferedImage pacman_0 =new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage pacman_down_1=new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage pacman_down_2=new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage pacman_up_1=new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage pacman_up_2=new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage pacman_left_1=new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage pacman_left_2=new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage pacman_right_1=new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage pacman_right_2=new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);

    BufferedImage ghost_blue_1f;
    BufferedImage ghost_blue_2f;
    
    BufferedImage ghost_orange_1f;
    BufferedImage ghost_orange_2f;
    
    BufferedImage ghost_pink_1f;
    BufferedImage ghost_pink_2f;
    
    BufferedImage ghost_red_1f;
    BufferedImage ghost_red_2f;
    
    BufferedImage ghost_scary_1f;
    BufferedImage ghost_scary_2f;
    
    BufferedImage ghost_blue_1 =new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage ghost_blue_2 =new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    
    BufferedImage ghost_orange_1 =new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage ghost_orange_2 =new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    
    
    BufferedImage ghost_pink_1 =new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage ghost_pink_2 =new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    
    BufferedImage ghost_red_1 =new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage ghost_red_2 =new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    
    BufferedImage ghost_scary_1 =new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage ghost_scary_2 =new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
    
    BufferedImage level_complete;
    BufferedImage game_over;
    
    boolean l_complete=false;
    boolean g_over=false;
    
    int x=0;
    
    int l=0;
    int ll=0;
    int lll=0;
    int llll=0;
    int lllll=0;
    
    public static int[][] board=new int[31][28];
    public static int[][] collision_map=new int[31][28];
    
    public Player player;
    
    public int dots_eaten=0;
    public int big_dots_eaten=0;
    
    public static ArrayList<Ghost> ghosts=new <Ghost>ArrayList();
    
    public PacMan()
    {
        try{
                
        ghosts=new <Ghost>ArrayList();
        
        level_complete=ImageIO.read(new File("Level_Complete.bmp"));
        game_over=ImageIO.read(new File("Game_Over.bmp"));
        
        corner_1=ImageIO.read(new File("corner_1.bmp"));
        
        corner_2=ImageIO.read(new File("corner_2.bmp"));
        corner_3=ImageIO.read(new File("corner_3.bmp"));
        corner_4=ImageIO.read(new File("corner_4.bmp"));
        vertical=ImageIO.read(new File("vertical.bmp"));
        horizontal=ImageIO.read(new File("horizontal.bmp"));
        big_dot=ImageIO.read(new File("big_dot.bmp"));
        dot=ImageIO.read(new File("dot.bmp"));
        
        pacman_0f=ImageIO.read(new File("pacman_0_20.bmp"));
        
        pacman_down_1f=ImageIO.read(new File("pacman_down_1_20.bmp"));
        pacman_down_2f=ImageIO.read(new File("pacman_down_2_20.bmp"));
        
        pacman_up_1f=ImageIO.read(new File("pacman_up_1_20.bmp"));
        pacman_up_2f=ImageIO.read(new File("pacman_up_2_20.bmp"));
        
        pacman_left_1f=ImageIO.read(new File("pacman_left_1_20.bmp"));
        pacman_left_2f=ImageIO.read(new File("pacman_left_2_20.bmp"));
        
        pacman_right_1f=ImageIO.read(new File("pacman_right_1_20.bmp"));
        pacman_right_2f=ImageIO.read(new File("pacman_right_2_20.bmp"));
        
        //BufferedImage pacman_0 = new BufferedImage(20,20,BufferedImage.TYPE_INT_ARGB);
        
        ghost_blue_1f=ImageIO.read(new File("blue_ghost_1_20.bmp"));
        ghost_blue_2f=ImageIO.read(new File("blue_ghost_2_20.bmp"));
        
        ghost_orange_1f=ImageIO.read(new File("orange_ghost_1_20.bmp"));
        ghost_orange_2f=ImageIO.read(new File("orange_ghost_2_20.bmp"));
        
        
        ghost_pink_1f=ImageIO.read(new File("pink_ghost_1_20.bmp"));
        ghost_pink_2f=ImageIO.read(new File("pink_ghost_2_20.bmp"));
        
        ghost_red_1f=ImageIO.read(new File("red_ghost_1_20.bmp"));
        ghost_red_2f=ImageIO.read(new File("red_ghost_2_20.bmp"));
        
        ghost_scary_1f=ImageIO.read(new File("scary_ghost_1_20.bmp"));
        ghost_scary_2f=ImageIO.read(new File("scary_ghost_2_20.bmp"));
        
        for(int y=0;y<20;y++){
        for(int x=0;x<20;x++){
        pacman_0.setRGB(x, y,1+pacman_0f.getRGB(x, y));
        pacman_left_1.setRGB(x, y,1+pacman_left_1f.getRGB(x, y));
        pacman_left_2.setRGB(x, y,1+pacman_left_2f.getRGB(x, y));
        pacman_right_1.setRGB(x, y,1+pacman_right_1f.getRGB(x, y));
        pacman_right_2.setRGB(x, y,1+pacman_right_2f.getRGB(x, y));
        
        pacman_up_1.setRGB(x, y,1+pacman_up_1f.getRGB(x, y));
        pacman_up_2.setRGB(x, y,1+pacman_up_2f.getRGB(x, y));
        
        pacman_down_1.setRGB(x, y,1+pacman_down_1f.getRGB(x, y));
        pacman_down_2.setRGB(x, y,1+pacman_down_2f.getRGB(x, y));
        
        //ghost_blue_1.setRGB(x, y,ghost_blue_1f.getRGB(x, y));
        //ghost_blue_2.setRGB(x, y,ghost_blue_2f.getRGB(x, y));
        //-16711681
        
        // tricky part making ghost mask only eyes are the same
        if(ghost_blue_1f.getRGB(x, y)==-16711681){ghost_blue_1.setRGB(x, y,ghost_blue_1f.getRGB(x, y));}
        else
        {
            if(y>4&&y<12&&x>2&&x<15){ghost_blue_1.setRGB(x, y,ghost_blue_1f.getRGB(x, y));}
            else{ghost_blue_1.setRGB(x, y,1+ghost_blue_1f.getRGB(x, y));}
        }
        
        if(ghost_blue_2f.getRGB(x, y)==-16711681){ghost_blue_2.setRGB(x, y,ghost_blue_2f.getRGB(x, y));}
        else
        {
            if(y>4&&y<12&&x>2&&x<15){ghost_blue_2.setRGB(x, y,ghost_blue_2f.getRGB(x, y));}
            else{ghost_blue_2.setRGB(x, y,1+ghost_blue_2f.getRGB(x, y));}
        }
        
        
        if(ghost_orange_1f.getRGB(x, y)==-16711681){ghost_orange_1.setRGB(x, y,ghost_orange_1f.getRGB(x, y));}
        else
        {
            if(y>4&&y<12&&x>2&&x<15){ghost_orange_1.setRGB(x, y,ghost_orange_1f.getRGB(x, y));}
            else{ghost_orange_1.setRGB(x, y,1+ghost_orange_1f.getRGB(x, y));}
        }
        
        if(ghost_orange_2f.getRGB(x, y)==-16711681){ghost_orange_2.setRGB(x, y,ghost_orange_2f.getRGB(x, y));}
        else
        {
            if(y>4&&y<12&&x>2&&x<15){ghost_orange_2.setRGB(x, y,ghost_orange_2f.getRGB(x, y));}
            else{ghost_orange_2.setRGB(x, y,1+ghost_orange_2f.getRGB(x, y));}
        }
        
        
        if(ghost_pink_1f.getRGB(x, y)==-16711681){ghost_pink_1.setRGB(x, y,ghost_pink_1f.getRGB(x, y));}
        else
        {
            if(y>4&&y<12&&x>2&&x<15){ghost_pink_1.setRGB(x, y,ghost_pink_1f.getRGB(x, y));}
            else{ghost_pink_1.setRGB(x, y,1+ghost_pink_1f.getRGB(x, y));}
        }
        
        if(ghost_pink_2f.getRGB(x, y)==-16711681){ghost_pink_2.setRGB(x, y,ghost_pink_2f.getRGB(x, y));}
        else
        {
            if(y>4&&y<12&&x>2&&x<15){ghost_pink_2.setRGB(x, y,ghost_pink_2f.getRGB(x, y));}
            else{ghost_pink_2.setRGB(x, y,1+ghost_pink_2f.getRGB(x, y));}
        }
        
        
        if(ghost_red_1f.getRGB(x, y)==-16711681){ghost_red_1.setRGB(x, y,ghost_red_1f.getRGB(x, y));}
        else
        {
            if(y>4&&y<12&&x>2&&x<15){ghost_red_1.setRGB(x, y,ghost_red_1f.getRGB(x, y));}
            else{ghost_red_1.setRGB(x, y,1+ghost_red_1f.getRGB(x, y));}
        }
        
        if(ghost_red_2f.getRGB(x, y)==-16711681){ghost_red_2.setRGB(x, y,ghost_red_2f.getRGB(x, y));}
        else
        {
            if(y>4&&y<12&&x>2&&x<15){ghost_red_2.setRGB(x, y,ghost_red_2f.getRGB(x, y));}
            else{ghost_red_2.setRGB(x, y,1+ghost_red_2f.getRGB(x, y));}
        }
        
        
        if(ghost_scary_1f.getRGB(x, y)==-16711681){ghost_scary_1.setRGB(x, y,ghost_scary_1f.getRGB(x, y));}
        else
        {
            if(y>4&&y<12&&x>2&&x<15){ghost_scary_1.setRGB(x, y,ghost_scary_1f.getRGB(x, y));}
            else
            {
                if(y>12&&y<16&&x>1&&x<17){ghost_scary_1.setRGB(x, y,ghost_scary_1f.getRGB(x, y));}else
                {
                    ghost_scary_1.setRGB(x, y,1+ghost_scary_1f.getRGB(x, y));
                }
            }
        }
        
        if(ghost_scary_2f.getRGB(x, y)==-16711681){ghost_scary_2.setRGB(x, y,ghost_scary_2f.getRGB(x, y));}
        else
        {
            if(y>4&&y<12&&x>2&&x<15){ghost_scary_2.setRGB(x, y,ghost_scary_2f.getRGB(x, y));}
            else
            {
                if(y>12&&y<16&&x>1&&x<17){ghost_scary_2.setRGB(x, y,ghost_scary_2f.getRGB(x, y));}else
                {
                ghost_scary_2.setRGB(x, y,1+ghost_scary_2f.getRGB(x, y));
                }
            }
        }
        
        
        }
        }
        
        
        player=new Player();
        
        Ghost g1=new Ghost("Red",14,11);
        Ghost g2=new Ghost("Blue",14,11);
        Ghost g3=new Ghost("Orange",14,11);
        Ghost g4=new Ghost("Pink",14,11);
        
        ghosts.add(g1);
        ghosts.add(g2);
        ghosts.add(g3);
        ghosts.add(g4);
        
        }catch(Exception exc){};
        
        this.addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        
        collision_map =new int[][]                                      {{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
									,{1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1}
									,{1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1}
									,{1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1}
									,{1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1}
									,{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1}
									,{1,0,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,0,1}
									,{1,0,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,0,1}
									,{1,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,1}
									,{1,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1}
									,{1,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0}
									,{1,1,1,1,1,1,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,1,1,1,1,1,0}
									,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0}
									,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1}
									,{0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0}
									,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1}
									,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0}
									,{1,1,1,1,1,1,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,1,1,1,1,1,0}
									,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0}
									,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1}
									,{1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1}
									,{1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1}
									,{1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1}
									,{1,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,1}
									,{1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1}
									,{1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1}
									,{1,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,1}
									,{1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1}
									,{1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1}
									,{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1}
									,{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
		};
                
        board =new int[][]                                              {{1,5,5,5,5,5,5,5,5,5,5,5,5,2,1,5,5,5,5,5,5,5,5,5,5,5,5,2}
									,{6,0,0,0,0,0,0,0,0,0,0,0,0,6,6,0,0,0,0,0,0,0,0,0,0,0,0,6}
									,{6,0,1,5,5,2,0,1,5,5,5,2,0,6,6,0,1,5,5,5,2,0,1,5,5,2,0,6}
									,{6,7,6,9,9,6,0,6,9,9,9,6,0,6,6,0,6,9,9,9,6,0,6,9,9,6,7,6}
									,{6,0,4,5,5,3,0,4,5,5,5,3,0,4,3,0,4,5,5,5,3,0,4,5,5,3,0,6}
									,{6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6}
									,{6,0,1,5,5,2,0,1,2,0,1,5,5,5,5,5,5,2,0,1,2,0,1,5,5,2,0,6}
									,{6,0,4,5,5,3,0,6,6,0,4,5,5,2,1,5,5,3,0,6,6,0,4,5,5,3,0,6}
									,{6,0,0,0,0,0,0,6,6,0,0,0,0,6,6,0,0,0,0,6,6,0,0,0,0,0,0,6}
									,{4,5,5,5,5,2,0,6,4,5,5,2,8,6,6,8,1,5,5,3,6,0,1,5,5,5,5,3}
									,{9,9,9,9,9,6,0,6,1,5,5,3,8,4,3,8,4,5,5,2,6,0,6,9,9,9,9,9}
									,{9,9,9,9,9,6,0,6,6,8,8,8,8,8,8,8,8,8,8,6,6,0,6,9,9,9,9,9}
									,{9,9,9,9,9,6,0,6,6,8,1,5,5,9,9,5,5,2,8,6,6,0,6,9,9,9,9,9}
									,{5,5,5,5,5,3,0,4,3,8,6,9,9,9,9,9,9,6,8,4,3,0,4,5,5,5,5,5}
									,{8,8,8,8,8,8,0,8,8,8,6,9,9,9,9,9,9,6,8,8,8,0,8,8,8,8,8,8}
									,{5,5,5,5,5,2,0,1,2,8,6,9,9,9,9,9,9,6,8,1,2,0,1,5,5,5,5,5}
									,{9,9,9,9,9,6,0,6,6,8,4,5,5,5,5,5,5,3,8,6,6,0,6,9,9,9,9,9}
									,{9,9,9,9,9,6,0,6,6,8,8,8,8,8,8,8,8,8,8,6,6,0,6,9,9,9,9,9}
									,{9,9,9,9,9,6,0,6,6,8,1,5,5,5,5,5,5,2,8,6,6,0,6,9,9,9,9,9}
									,{1,5,5,5,5,3,0,4,3,8,4,5,5,2,1,5,5,3,8,4,3,0,4,5,5,5,5,2}
									,{6,0,0,0,0,0,0,0,0,0,0,0,0,6,6,0,0,0,0,0,0,0,0,0,0,0,0,6}
									,{6,0,1,5,5,2,0,1,5,5,5,2,0,6,6,0,1,5,5,5,2,0,1,5,5,2,0,6}
									,{6,0,4,5,2,6,0,4,5,5,5,3,0,4,3,0,4,5,5,5,3,0,6,1,5,3,0,6}
									,{6,7,0,0,6,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,6,0,0,7,6}
									,{4,5,2,0,6,6,0,1,2,0,1,5,5,5,5,5,5,2,0,1,2,0,6,6,0,1,5,3}
									,{1,5,3,0,4,3,0,6,6,0,4,5,5,2,1,5,5,3,0,6,6,0,4,3,0,4,5,2}
									,{6,0,0,0,0,0,0,6,6,0,0,0,0,6,6,0,0,0,0,6,6,0,0,0,0,0,0,6}
									,{6,0,1,5,5,5,5,3,4,5,5,2,0,6,6,0,1,5,5,3,4,5,5,5,5,2,0,6}
									,{6,0,4,5,5,5,5,5,5,5,5,3,0,4,3,0,4,5,5,5,5,5,5,5,5,3,0,6}
									,{6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6}
									,{4,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3}
		};

    }
    
    public void restart_game()
    {
    ghosts=new <Ghost>ArrayList();
    player=new Player();
        
        Ghost g1=new Ghost("Red",14,11);
        Ghost g2=new Ghost("Blue",14,11);
        Ghost g3=new Ghost("Orange",14,11);
        Ghost g4=new Ghost("Pink",14,11);
        
        ghosts.add(g1);
        ghosts.add(g2);
        ghosts.add(g3);
        ghosts.add(g4);
        
        l_complete=false;
        g_over=false;
    
        x=0;
    
        l=0;
        ll=0;
        lll=0;
        llll=0;
        lllll=0;
        dots_eaten=0;
        big_dots_eaten=0;
        
        board =new int[][]                                              {{1,5,5,5,5,5,5,5,5,5,5,5,5,2,1,5,5,5,5,5,5,5,5,5,5,5,5,2}
									,{6,0,0,0,0,0,0,0,0,0,0,0,0,6,6,0,0,0,0,0,0,0,0,0,0,0,0,6}
									,{6,0,1,5,5,2,0,1,5,5,5,2,0,6,6,0,1,5,5,5,2,0,1,5,5,2,0,6}
									,{6,7,6,9,9,6,0,6,9,9,9,6,0,6,6,0,6,9,9,9,6,0,6,9,9,6,7,6}
									,{6,0,4,5,5,3,0,4,5,5,5,3,0,4,3,0,4,5,5,5,3,0,4,5,5,3,0,6}
									,{6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6}
									,{6,0,1,5,5,2,0,1,2,0,1,5,5,5,5,5,5,2,0,1,2,0,1,5,5,2,0,6}
									,{6,0,4,5,5,3,0,6,6,0,4,5,5,2,1,5,5,3,0,6,6,0,4,5,5,3,0,6}
									,{6,0,0,0,0,0,0,6,6,0,0,0,0,6,6,0,0,0,0,6,6,0,0,0,0,0,0,6}
									,{4,5,5,5,5,2,0,6,4,5,5,2,8,6,6,8,1,5,5,3,6,0,1,5,5,5,5,3}
									,{9,9,9,9,9,6,0,6,1,5,5,3,8,4,3,8,4,5,5,2,6,0,6,9,9,9,9,9}
									,{9,9,9,9,9,6,0,6,6,8,8,8,8,8,8,8,8,8,8,6,6,0,6,9,9,9,9,9}
									,{9,9,9,9,9,6,0,6,6,8,1,5,5,9,9,5,5,2,8,6,6,0,6,9,9,9,9,9}
									,{5,5,5,5,5,3,0,4,3,8,6,9,9,9,9,9,9,6,8,4,3,0,4,5,5,5,5,5}
									,{8,8,8,8,8,8,0,8,8,8,6,9,9,9,9,9,9,6,8,8,8,0,8,8,8,8,8,8}
									,{5,5,5,5,5,2,0,1,2,8,6,9,9,9,9,9,9,6,8,1,2,0,1,5,5,5,5,5}
									,{9,9,9,9,9,6,0,6,6,8,4,5,5,5,5,5,5,3,8,6,6,0,6,9,9,9,9,9}
									,{9,9,9,9,9,6,0,6,6,8,8,8,8,8,8,8,8,8,8,6,6,0,6,9,9,9,9,9}
									,{9,9,9,9,9,6,0,6,6,8,1,5,5,5,5,5,5,2,8,6,6,0,6,9,9,9,9,9}
									,{1,5,5,5,5,3,0,4,3,8,4,5,5,2,1,5,5,3,8,4,3,0,4,5,5,5,5,2}
									,{6,0,0,0,0,0,0,0,0,0,0,0,0,6,6,0,0,0,0,0,0,0,0,0,0,0,0,6}
									,{6,0,1,5,5,2,0,1,5,5,5,2,0,6,6,0,1,5,5,5,2,0,1,5,5,2,0,6}
									,{6,0,4,5,2,6,0,4,5,5,5,3,0,4,3,0,4,5,5,5,3,0,6,1,5,3,0,6}
									,{6,7,0,0,6,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,6,0,0,7,6}
									,{4,5,2,0,6,6,0,1,2,0,1,5,5,5,5,5,5,2,0,1,2,0,6,6,0,1,5,3}
									,{1,5,3,0,4,3,0,6,6,0,4,5,5,2,1,5,5,3,0,6,6,0,4,3,0,4,5,2}
									,{6,0,0,0,0,0,0,6,6,0,0,0,0,6,6,0,0,0,0,6,6,0,0,0,0,0,0,6}
									,{6,0,1,5,5,5,5,3,4,5,5,2,0,6,6,0,1,5,5,3,4,5,5,5,5,2,0,6}
									,{6,0,4,5,5,5,5,5,5,5,5,3,0,4,3,0,4,5,5,5,5,5,5,5,5,3,0,6}
									,{6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6}
									,{4,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3}
		};
    };
    
    public static void main(String[] args) {
        
        PacMan p=new PacMan();
        p.panel = p;
        p.frame = new JFrame("Pac Man");
        p.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        p.frame.getContentPane().add(p.panel);
        p.panel.setSize(300, 300);
        p.frame.setLocation(500, 100);
        p.frame.pack();
        p.frame.show();
        p.thread=new Thread(p);
        p.thread.start();
        
    }

    public Dimension getPreferredSize(){
        return new Dimension(448, 496);
    }
   
    /*
    public void up(){player.next_move_dir=8; if (player.able_up) player.move_dir=8;}
    public void down(){player.next_move_dir=2; if (player.able_down) player.move_dir=2;}
    public void left(){player.next_move_dir=4; if (player.able_left) player.move_dir=4;}
    public void right(){player.next_move_dir=6; if (player.able_right) player.move_dir=6;}
    */
    
    public void up(){player.next_move_dir=8; }
    public void down(){player.next_move_dir=2; }
    public void left(){player.next_move_dir=4; }
    public void right(){player.next_move_dir=6; }
    
    @Override
    public void run() {
        while(true)
        {
        try{
        
        if(l_complete||g_over){
            lllll++;
            if(lllll==1500)
            {lllll=0;
            l_complete=false;
            g_over=false;
            
            restart_game();
            }
        }
        
        int sum=(dots_eaten+big_dots_eaten);
        if(sum==246){l_complete=true;};
        
        llll++;
        if(llll==8000){llll=0;makes_ghosts_normal();}
        
        ll++;if(ll==16) ll=0;
        if(ll==0)
        {
            if(g_over==false) player.move();
            for(Ghost g:ghosts){if(g_over==false) g.move();}
        }
        
        l++;if(l==80) l=0;
        if(l==0){
            player.set_frame();
        }
        
        lll++;if(lll==160) lll=0;
        if(lll==0){
            for(Ghost g:ghosts){g.animate();}
        }
        
        
        if(board[player.y][player.x]==0){
            dots_eaten++;
            board[player.y][player.x]=9;
        }
        
        if(board[player.y][player.x]==7){
            big_dots_eaten++;
            board[player.y][player.x]=9;
            make_ghosts_scary();
        }
        
        check_collision_player_with_ghosts();
        
        //System.out.println("dots "+dots_eaten);
        //System.out.println("big dots "+big_dots_eaten);
        
        this.repaint();
        Thread.sleep(1);
        }catch(Exception exc){};
        }
    }
    
    public void check_collision_player_with_ghosts()
    {
        for(Ghost g:ghosts)
        {
            if(g.scary_state&&g.alive){
                if(player.pos_y>=g.pos_y&&player.pos_y<=g.pos_y+20)
                {
                if(player.pos_x>=g.pos_x&&player.pos_x<=g.pos_x+20)
                {
                 g.alive=false;
                 ghosts.add(new Ghost(g.ghost_type,14,11));
                }
                }
            }
            
            if(g.scary_state==false&&g.alive){
                if(player.pos_y>=g.pos_y&&player.pos_y<=g.pos_y+20)
                {
                if(player.pos_x>=g.pos_x&&player.pos_x<=g.pos_x+20)
                {
                    g.alive=false;
                    g_over=true;
                }
                }
            }
            
            
        }
    }
    
    public void make_ghosts_scary()
    {
        llll=0;
        for(Ghost g:ghosts){g.scary_state=true;};
    };
    
    public void makes_ghosts_normal()
    {
        for(Ghost g:ghosts){g.scary_state=false;};
    };
    
            
    //tile 8x8
    //board 28x31
    public void paintComponent(Graphics g){
    	super.paintComponent(g);
        g.setColor(Color.white);
        g.setColor(new Color(255,255,255));
        g.setColor(new Color(0,0,0));
        g.fillRect(0, 0, 672, 864);
        
        
        for(int y=0;y<31;y++)
        {
        for(int x=0;x<28;x++)
        {
        if(board[y][x]==0) g.drawImage(dot, x*16, y*16, null);
        if(board[y][x]==1) g.drawImage(corner_1, x*16, y*16, null);
        if(board[y][x]==2) g.drawImage(corner_2, x*16, y*16, null);
        if(board[y][x]==3) g.drawImage(corner_3, x*16, y*16, null);
        if(board[y][x]==4) g.drawImage(corner_4, x*16, y*16, null);
        if(board[y][x]==5) g.drawImage(horizontal, x*16, y*16, null);
        if(board[y][x]==6) g.drawImage(vertical, x*16, y*16, null);
        if(board[y][x]==7) g.drawImage(big_dot, x*16, y*16, null);
        }
        }
        
        
        if(player.current_frame==0) g.drawImage(pacman_0, player.pos_x-2, player.pos_y-2, null);
        
        if(player.current_frame==2) g.drawImage(pacman_up_1, player.pos_x-2, player.pos_y-2, null);
        if(player.current_frame==3) g.drawImage(pacman_up_2, player.pos_x-2, player.pos_y-2, null);
        
        if(player.current_frame==4) g.drawImage(pacman_down_1, player.pos_x-2, player.pos_y-2, null);
        if(player.current_frame==5) g.drawImage(pacman_down_2, player.pos_x-2, player.pos_y-2, null);
        
        if(player.current_frame==6) g.drawImage(pacman_left_1, player.pos_x-2, player.pos_y-2, null);
        if(player.current_frame==7) g.drawImage(pacman_left_2, player.pos_x-2, player.pos_y-2, null);
        
        
        if(player.current_frame==8) g.drawImage(pacman_right_1, player.pos_x-2, player.pos_y-2, null);
        
        if(player.current_frame==9) g.drawImage(pacman_right_2, player.pos_x-2, player.pos_y-2, null);
        
        /*
        g.drawImage(ghost_blue_1, player.pos_x+20, player.pos_y-2, null);
        g.drawImage(ghost_blue_2, player.pos_x+40, player.pos_y-2, null);
        
        g.drawImage(ghost_orange_1, player.pos_x+60, player.pos_y-2, null);
        g.drawImage(ghost_orange_2, player.pos_x+80, player.pos_y-2, null);
        
        g.drawImage(ghost_pink_1, player.pos_x+100, player.pos_y-2, null);
        g.drawImage(ghost_pink_2, player.pos_x+120, player.pos_y-2, null);
        
        g.drawImage(ghost_red_1, player.pos_x+140, player.pos_y-2, null);
        g.drawImage(ghost_red_2, player.pos_x+160, player.pos_y-2, null);
        
        g.drawImage(ghost_scary_1, player.pos_x+180, player.pos_y-2, null);
        g.drawImage(ghost_scary_2, player.pos_x+200, player.pos_y-2, null);
        */
        
        for(Ghost ghost:ghosts)
        {
                    if(ghost.alive){
                    if(ghost.scary_state==false){
                        if(ghost.current_frame==0){
                            if(ghost.ghost_type.equals("Red")){g.drawImage(ghost_red_1, ghost.pos_x, ghost.pos_y-2, null);}
                            if(ghost.ghost_type.equals("Blue")){g.drawImage(ghost_blue_1, ghost.pos_x, ghost.pos_y-2, null);}
                            if(ghost.ghost_type.equals("Orange")){g.drawImage(ghost_orange_1, ghost.pos_x, ghost.pos_y-2, null);}
                            if(ghost.ghost_type.equals("Pink")){g.drawImage(ghost_pink_1, ghost.pos_x, ghost.pos_y-2, null);}
                        }
                        if(ghost.current_frame==1){
                            if(ghost.ghost_type.equals("Red")){g.drawImage(ghost_red_2, ghost.pos_x, ghost.pos_y-2, null);}
                            if(ghost.ghost_type.equals("Blue")){g.drawImage(ghost_blue_2, ghost.pos_x, ghost.pos_y-2, null);}
                            if(ghost.ghost_type.equals("Orange")){g.drawImage(ghost_orange_2, ghost.pos_x, ghost.pos_y-2, null);}
                            if(ghost.ghost_type.equals("Pink")){g.drawImage(ghost_pink_2, ghost.pos_x, ghost.pos_y-2, null);}
                        }
                    }
                    if(ghost.scary_state==true){
                        if(ghost.current_frame==0){
                            g.drawImage(ghost_scary_1, ghost.pos_x, ghost.pos_y-2, null);
                        }
                        if(ghost.current_frame==1){
                            g.drawImage(ghost_scary_2, ghost.pos_x, ghost.pos_y-2, null);
                        }
                    }
                    }
        }
        
        if(l_complete==true) g.drawImage(level_complete, 170, 220, null);
        if(g_over==true) g.drawImage(game_over, 180, 220, null);
    }
    
    @Override
    public void keyTyped(KeyEvent ke) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode()==87){up();}
        if(e.getKeyCode()==83){down();}
        if(e.getKeyCode()==65){left();}
        if(e.getKeyCode()==68){right();}
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        
    }
    
}
